var fill_color = 'white'
var fill_color1 = 'white'
var fill_color2 = 'white'


function setup() { 
  createCanvas(windowWidth, windowHeight);
} 

function draw() { 
  background(0);
	ellipse(50,50,50,50);
  	if (mouseX < 4 * windowWidth / 3) {
      bgColor = '#6638F0';
  
  ellipse(50,107,50,50);
	
  
  ellipse(50,160,50,50);




}

if (mouseX < 4 * windowWidth / 5) {
   // bgColor = '#6638F0';
  //} else if (mouseX < 3 * windowWidth / 5) {
  //  bgColor = '#890424';
 // } else if (mouseX < 2 * windowWidth / 5) {
 //   bgColor = '#20C8B6';
 // } else if (mouseX < windowWidth / 5) {
  //  bgColor = '#82BCFB';
 // } else {
  //  bgColor = '#E12874';
 // }
//}